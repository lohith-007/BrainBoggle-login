//var db = firebase.firestore();
const form = document.querySelector('#registration')


form.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = form['emailsignup'].value;
    const password = form['passwordsignup'].value;
    db.collection('facutly-registration').add({
        first_name: form.firstnamesignup.value,
        last_name: form.lastnamesignup.value,
        phone_number: form.phonenumbersignup.value,
        user_name : form.usernamesignup.value,
        mail_id :form.emailsignup.value,
        password : form.passwordsignup.value
    })
   //sign up the user
   auth.createUserWithEmailAndPassword(email, password).catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    alert(errorCode)
    alert(errorMessage)
    
  
  

  
});


});


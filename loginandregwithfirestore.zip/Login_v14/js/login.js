
//login
const loginform =  document.querySelector('#loginform');
loginform.addEventListener('submit',(e) => {
    e.preventDefault();
   
    // user info
    const email = loginform['username'].value;
    const password = loginform['password'].value;

    auth.signInWithEmailAndPassword(email , password).then(cred =>{
      console.log(cred.user)
    })


    //auth state change


      
})

